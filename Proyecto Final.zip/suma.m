.data

	matrizA:	.word 2, 3 
				.word 1, 6 
	matrizB:	.word 2, 6 
					.word 7, 3 
	nroColumnas: 	.word 2

	.eqv longitudDato 4

	espacio: .asciiz " "
	salto: .asciiz "\n"

.text   
	principal: 
		la $s0, matrizA	 		
		la $s1, matrizB
		lw $s7, nroColumnas 

		add $t0, $zero, 0
	  	bucle1:
	  		mul $t1, $t0, $s7					

			add $t6, $zero, 0
	  		bucle2:
			  	addi $t2, $t1, 0
	  			add $t2, $t2, $t6					
	   			mul $t2, $t2, longitudDato 

	   			add $t3, $t2, $s0 		
				add $t4, $t2, $s1		
			
				lw $s3, ($t3)   	 	
				lw $s4, ($t4)
				add $t3, $s3, $s4

	   			move $a0, $t3 
	 			li $v0, 1				 
	  			syscall	   							

				li $v0, 4
				la $a0, espacio
				syscall

	 	  		addi $t6, $t6, 1						 					
	   			blt $t6, $s7, bucle2		 				

				li $v0, 4
				la $a0, salto
				syscall

	   		addi $t0, $t0, 1					 	
	   		blt $t0, $s7, bucle1		